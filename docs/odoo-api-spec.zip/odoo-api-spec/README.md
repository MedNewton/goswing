# GoSwing — Odoo API Spec

This directory is a contract handed to the Odoo team. It tells them exactly what to
build on the Odoo side so the React Native app can stop talking to Supabase and
start talking to Odoo directly.

It contains:

- `schema.json` — every Odoo model we need, with fields, types, indexes,
  constraints, and ownership rules. Source of truth: `context/database.sql`.
- `routes/<domain>.json` — every HTTP endpoint the RN app will call, with
  request shape, response shape, auth, authorization, and a `supabase_source`
  pointer to the function being replaced. One file per domain (mirrors
  `lib/supabase/<domain>.ts`).
- `README.md` (this file) — global conventions every route obeys.

The Odoo team builds the API. We build only the RN-side `lib/api/` modules
that consume it.

---

## 1. Authentication

Every request (except those marked `auth.required: false`) carries:

```
Authorization: Bearer <clerk-jwt>
```

The token is a Clerk-issued JWT. The Odoo controller MUST:

1. Fetch and cache Clerk's JWKS from
   `https://<clerk-frontend-api>/.well-known/jwks.json`
   (Clerk frontend API URL is provided as a config secret).
2. Verify the JWT signature using the matching JWK (`kid` claim).
3. Verify `exp`, `iat`, `nbf` claims.
4. Verify `iss` matches the configured Clerk issuer URL.
5. Extract the `sub` claim — this is the **Clerk user id** (a string like
   `user_2abc...`). It is the identity used for all per-row authorization.

Failure → respond `401 unauthenticated` (see § 4 error envelope).

The Clerk user id is **never accepted from the request body**. It is always
derived from the verified JWT.

## 2. Identity & ID space

| Concept | Odoo internal | Public (API) | Notes |
|---|---|---|---|
| Row identity | `id` (Odoo int, auto-increment) | **never exposed** | Internal-only. |
| Public id | `external_id` (Char, unique, indexed) | `id` field in JSON | This is the original Supabase UUID. The RN client uses these as stable identifiers. |
| Human-readable alias (events only) | `slug` (Char, unique, nullable) | `externalId` field in JSON | Originally `events.external_id` in Supabase (e.g. `"evt_005"`). Renamed in Odoo to free up `external_id` for the UUID. |
| User identity | `clerk_user_id` (Char, indexed) | not always exposed | Populated from JWT `sub` on writes. Never accepted from request body. |

**The RN client never sees Odoo's int ids.** Every API response that includes
an id MUST serialize the `external_id` UUID as the `id` field.

## 3. Naming convention

- **DB / Odoo models:** `snake_case`. Models prefixed `goswing.` (e.g.
  `goswing.event`, `goswing.event_favorite`).
- **JSON request/response fields:** `camelCase` (e.g. `startsAt`, `minPriceCents`).
  This matches the existing TypeScript surface — the RN code does **not**
  re-shape responses.
- **HTTP paths:** `kebab-case` (e.g. `/v1/song-suggestions`, `/v1/me/reservations`).
- **Versioning:** all routes prefixed `/v1/`.

## 4. Error envelope

Every non-2xx response uses this shape:

```json
{
  "error": {
    "code": "validation_failed",
    "message": "Email is required",
    "details": { "field": "email" }
  }
}
```

| HTTP | code | Trigger |
|---|---|---|
| 400 | `validation_failed` | Bad input (missing field, wrong type, out-of-range value). `details.field` indicates which. |
| 401 | `unauthenticated` | JWT missing, invalid, or expired. |
| 403 | `forbidden` | Authentication OK, but the user is not allowed to perform this action on this record. |
| 404 | `not_found` | Record id not found. |
| 409 | `conflict` | Duplicate — e.g. already favorited, already reviewed. |
| 422 | `unprocessable` | Business-rule violation (e.g. ticket type sold out, sales window closed). `details.reason` indicates which. |
| 429 | `rate_limited` | Throttled. |
| 500 | `internal_error` | Anything else. |

A 2xx response **never** uses this envelope; success bodies are domain objects.

## 5. Response conventions

- **Datetimes:** ISO 8601 with timezone (`2026-04-29T19:00:00Z`). Always UTC unless
  otherwise stated. Odoo internal storage is naive datetime (UTC) — serialize with
  trailing `Z`.
- **Money:** integer cents in field name `*Cents` (e.g. `priceCents: 2500`). Currency
  in a sibling `currency` field as a 3-letter uppercase ISO 4217 code (`USD`, `EUR`).
- **Booleans:** `true` / `false`. Never `0`/`1`, never `"yes"`/`"no"`.
- **Nullables:** explicit `null`. Avoid omitting nullable fields — always include the key.
- **Arrays:** never `null`; use `[]`. (Empty list = no rows.)
- **Optional fields:** may be omitted entirely (key absent) when the value is unknown.
  This matches existing TS optional fields.
- **Pagination:** for list endpoints with potentially large result sets, accept
  `?limit=N&offset=N`. Default limit is documented per route. List responses are
  bare arrays (no envelope) unless the route says otherwise.

## 6. Authorization model (replaces Supabase RLS)

There is no global RLS-style enforcement on Odoo. Every controller method MUST:

1. Verify the JWT (per § 1) and extract `clerk_user_id`.
2. Apply the per-route policy documented in `routes/*.json` under
   `authorization`. Common policies:
   - `any_authenticated_user` — JWT validity is enough.
   - `record_owner` — the row's `clerk_user_id` must equal the JWT `sub`.
   - `organizer_member` — the JWT `sub` must appear in `goswing.organizer_member`
     for the targeted organizer.
   - `public_read` — no auth required (rare; explicitly marked).

For per-record checks, **always read the row first, check ownership, then act.**
Never trust ids in the request body to imply ownership.

## 7. Transactional integrity

Reservation creation cascades into 4 related models (see `routes/checkout.json`).
The endpoint MUST commit atomically — either all rows persist, or none do.
Use Odoo's ORM transaction (one `@http.route` invocation = one Postgres
transaction by default). If business validation fails mid-cascade, raise an
exception so the transaction rolls back.

## 8. Currency

The schema stores `currency` as `character` (length 1) in some places — that's a
Supabase bug (it should be `char(3)`). On Odoo, store as `Char(size=3)` with
default `'USD'`. We will fix the legacy data on migration.

## 9. Server-derived fields

The server MUST compute (never accept from client) these fields on every write:

- `created_at`, `updated_at`
- `clerk_user_id` (from JWT)
- `external_id` UUID (auto-generate on `create` if not provided; on data
  migration, preserve the original Supabase UUID)
- All money totals on reservation create — recompute from `ticket_type.price_cents`,
  not from request body
- `expires_at` on `event_story` (always `now() + 24h`)

The client may send these fields and the server MUST ignore them.

## 10. File storage

The only file-upload route is `POST /v1/stories` (multipart/form-data). The
Odoo team to confirm storage strategy:

- **Option A (preferred):** Odoo accepts the multipart upload, stores the binary
  in an `ir.attachment` (or filesystem mount), and returns a public URL with
  24h signed-token expiry.
- **Option B:** RN app uploads directly to a CDN (e.g. Cloudflare R2) using a
  pre-signed URL the Odoo route returns; the Odoo `goswing.event_story` row
  stores the public URL.

Decision pending — see § Open questions in the migration design doc.

## 11. Things explicitly out of scope for this spec

- **Realtime / push pipelines.** Push notifications use Expo directly; not
  Odoo's responsibility.
- **Stripe webhooks.** Will be added once payments go live (Q3 in design doc).
- **Admin tooling for organizers.** Out of scope.
- **Returning `null` to mean "field missing."** Always include the key with
  explicit `null`.

## 12. Conventions for `routes/*.json` files

Each file is one domain (mirrors a `lib/supabase/<domain>.ts` file). Top-level
shape:

```json
{
  "domain": "events",
  "supabase_source_file": "lib/supabase/events.ts",
  "routes": [ /* one entry per endpoint */ ],
  "$types": { /* shared response/request types referenced by $ref */ }
}
```

Each route entry:

```json
{
  "name": "getPublishedEvents",
  "method": "GET",
  "path": "/v1/events",
  "summary": "List all published events.",
  "auth": { "required": true, "type": "clerk_jwt" },
  "authorization": "any_authenticated_user",
  "request": {
    "path_params": {},
    "query": {},
    "body": null
  },
  "response": {
    "status": 200,
    "body": { "type": "array", "items": { "$ref": "#/$types/Event" } }
  },
  "errors": [
    { "status": 401, "code": "unauthenticated" },
    { "status": 500, "code": "internal_error" }
  ],
  "supabase_source": "lib/supabase/events.ts:getPublishedEvents (line 150)",
  "odoo_hint": "Optional implementation note for the Odoo dev — model + key joins.",
  "example_response": [ /* one realistic example */ ]
}
```

`$ref` strings point either inside the same file (`#/$types/Foo`) or into
`schema.json` (`schema.json#/models/<odoo_name>`).

---

## Status

- `schema.json` — complete (all 33 tables).
- `routes/events.json` — prototype (this is the format we want to lock down).
- `routes/*.json` for the other 9 domains — not yet generated. Will follow
  once the Odoo manager confirms the format.

## Open questions for the Odoo manager

1. **Storage.** Option A vs Option B in § 10?
2. **Clerk JWKS caching.** OK to cache for 1h with key-rotation refresh on
   verify-fail? Or do you want a different cadence?
3. **Format.** Is this JSON shape easy to consume? Would you prefer
   OpenAPI 3 / JSON Schema instead? We can convert.
4. **Versioning.** OK with `/v1/` prefix and `spec_version` field in schema?
5. **Pagination.** OK with `?limit=N&offset=N`? Or do you prefer cursor-based?
